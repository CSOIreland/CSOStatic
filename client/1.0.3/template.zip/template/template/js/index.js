$(document).ready(function () {
	//  Get Header
	csolib_loadContent('.header-container', 'template/header.html');

	// Get Navigation
	csolib_loadContent('.nav-container', 'template/nav.html');

	// Get Footer
	csolib_loadContent('.footer-container', 'template/footer.html');

	// Get Default Body
	csolib_loadContent('.body-container', 'entity/link-a/');
});
