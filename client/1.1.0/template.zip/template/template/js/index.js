$(document).ready(function () {
    if (!csolib_getNoHeader())
	    //  Get Header
	    csolib_loadContent('.header-container', 'template/header.html');

	if (!csolib_getNoNavbar())
	    // Get Navigation
	    csolib_loadContent('.nav-container', 'template/nav.html');

	if (!csolib_getBody())
	    // Get Default Body
	    csolib_loadContent('.body-container', 'entity/link-a/');
	else
	    // Get Custom Body
	    csolib_loadContent('.body-container', csolib_getBody());

	if (!csolib_getNoFooter())
	    // Get Footer
	    csolib_loadContent('.footer-container', 'template/footer.html');

    // Get Overlay
	csolib_loadContent('.overlay-container', 'template/overlay.html');
});
