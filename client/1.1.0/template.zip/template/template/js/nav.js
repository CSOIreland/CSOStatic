$(document).ready(function () {
	// Load Link A when clicking on the Logo
	csolib_navContent('#mainLogo', 'entity/link-a/', null);

	// Load Link A on click
	csolib_navContent('#page-link-a', 'entity/link-a/', '#page-link-a');

	// Load Link B on click
	csolib_navContent('#page-link-b', 'entity/link-b/', '#page-link-b', '#page-menu-1');

	// Load Link C on click
	csolib_navContent('#page-link-c', 'entity/link-c/', '#page-link-c', '#page-menu-1');

});
