$(document).ready(function () {
    if (!cso.uri.getNoHeader())
	    //  Get Header
        cso.content.load('.header-container', 'template/header.html');

    if (!cso.uri.getNoNavbar())
	    // Get Navigation
        cso.content.load('.nav-container', 'template/nav.html');

    if (!cso.uri.getBody())
	    // Get Default Body
        cso.content.load('.body-container', 'entity/link-a/');
	else
	    // Get Custom Body
        cso.content.load('.body-container', cso.uri.getBody());

    if (!cso.uri.getNoFooter())
	    // Get Footer
        cso.content.load('.footer-container', 'template/footer.html');

    // Get Overlay
    cso.content.load('.overlay-container', 'template/overlay.html');
});
