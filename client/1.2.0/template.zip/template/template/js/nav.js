$(document).ready(function () {
	// Load Link A when clicking on the Logo
    cso.content.navigate('#mainLogo', 'entity/link-a/');

	// Load Link A on click
    cso.content.navigate('#page-link-a', 'entity/link-a/', '#page-link-a');

	// Load Link B on click
    cso.content.navigate('#page-link-b', 'entity/link-b/', '#page-link-b', '#page-menu-1');

	// Load Link C on click
    cso.content.navigate('#page-link-c', 'entity/link-c/', '#page-link-c', '#page-menu-1');
});
