/*******************************************************************************
Custom JS application specific
*******************************************************************************/
$(document).ready(function () {
    // Start the Drag n Drop
    api.plugin.dragndrop.initiate(document, window);
});

