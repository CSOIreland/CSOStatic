/*******************************************************************************
Application - Constant
*******************************************************************************/

// Sample of a Application Constant
const C_APP_SOMETHING = 'Assign here the value of the constant';